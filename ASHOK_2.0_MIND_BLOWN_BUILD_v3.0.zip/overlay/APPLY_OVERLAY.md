# ASHOK 2.0 self-build overlay

Copy the contents of this directory into the root of the existing GitHub Pages repository.

## Preserve
Do **not** delete or replace:
- `_posts/`
- `_config.yml`
- existing `/blog/`
- existing `/images/` unless a specific new asset is intentionally added
- `CNAME`

The overlay adds the new commercial pages, Insights pages, Tools, visual system, LinkedIn automation and shared CSS/JS.

## Deployment gate
Before publishing, verify the two legacy Jekyll blog URLs already present in the repository. Do not remove the legacy blog merely because the new Insights system exists.

## LinkedIn
Set the four GitHub Actions secrets described in `automation/linkedin/README.md`. Keep `AUTO_PUBLISH=false` until OAuth and the member posting permission have been tested.

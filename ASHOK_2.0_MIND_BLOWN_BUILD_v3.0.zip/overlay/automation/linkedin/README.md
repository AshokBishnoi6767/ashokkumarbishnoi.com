# LinkedIn automation

Approval queue → GitHub Actions → LinkedIn Posts API → publication state.

Required GitHub secrets: `LINKEDIN_ACCESS_TOKEN`, `LINKEDIN_PERSON_URN`, `LINKEDIN_VERSION`, `AUTO_PUBLISH`.

Keep `AUTO_PUBLISH=false` until OAuth and `w_member_social` have been verified. Approve posts by adding `{ "id": "unique-id", "approved": true, "text": "...", "url": "https://ashokkumarbishnoi.com/..." }` to `automation/linkedin/queue.json`.

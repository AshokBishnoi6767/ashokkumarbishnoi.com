import json, os, urllib.request
from pathlib import Path
if os.getenv('AUTO_PUBLISH','false').lower() != 'true':
    print('AUTO_PUBLISH is not true; safe exit.'); raise SystemExit(0)
token=os.environ.get('LINKEDIN_ACCESS_TOKEN'); urn=os.environ.get('LINKEDIN_PERSON_URN'); version=os.environ.get('LINKEDIN_VERSION')
if not all([token,urn,version]): raise SystemExit('Missing LinkedIn secrets.')
root=Path(__file__).resolve().parents[2]; q=root/'automation/linkedin/queue.json'; st=root/'automation/linkedin/state.json'
queue=json.loads(q.read_text()) if q.exists() else []; state=json.loads(st.read_text()) if st.exists() else {'published':[]}
items=[x for x in queue if x.get('approved') is True and x.get('id') not in state.get('published',[])]
if not items: print('No approved unpublished LinkedIn item.'); raise SystemExit(0)
item=items[0]; text=item['text'].strip(); url=item.get('url')
if url and url not in text: text+='\n\nRead more: '+url
payload={'author':urn,'commentary':text,'visibility':'PUBLIC','distribution':{'feedDistribution':'MAIN_FEED','targetEntities':[],'thirdPartyDistributionChannels':[]},'lifecycleState':'PUBLISHED','isReshareDisabledByAuthor':False}
req=urllib.request.Request('https://api.linkedin.com/rest/posts',data=json.dumps(payload).encode(),method='POST',headers={'Authorization':f'Bearer {token}','Content-Type':'application/json','Linkedin-Version':version,'X-Restli-Protocol-Version':'2.0.0'})
with urllib.request.urlopen(req,timeout=30) as r: print(r.status,r.read().decode())
state.setdefault('published',[]).append(item['id']); st.write_text(json.dumps(state,indent=2)+'\n')
